import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { randomUUID } from 'crypto';
import multer from 'multer';
import { generateRAGResponse } from './services/rag.js';
import { generateBookingResponse, checkBookingConfirmation } from './services/bookingAgent.js';
import * as bookingService from './services/booking.js';
import * as parkingService from './services/parking.js';
import { processAudioFile } from './services/transcription.js';
import { crawlSite } from './services/crawler.js';
import { textToSpeech } from './services/textToSpeech.js';
import { getDoctors, getServices, extractDoctorsAndServices } from './services/websiteData.js';
import { db, lowDb } from './config/database.js';
import { processBookingMessage, detectBookingStart, getBookingState } from './services/conversationalBooking.js';
import { detectProblemDescription, generateRecommendationResponse } from './services/doctorRecommendation.js';
import { classifyQueryIntent } from './services/queryClassifier.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Multer for file uploads
const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB max
});

// Session management (simple in-memory for demo)
const sessions = new Map();

function getOrCreateSession(sessionId) {
  if (!sessionId || !sessions.has(sessionId)) {
    const newSessionId = randomUUID();
    sessions.set(newSessionId, {
      id: newSessionId,
      bookingState: null,
      parkingState: null,
      createdAt: new Date()
    });
    return newSessionId;
  }
  return sessionId;
}

// Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Helper function to detect doctor/service queries
async function detectDoctorServiceQuery(message) {
  const lowerMessage = message.toLowerCase().trim();
  
  // First, check if this is an informational query (should NOT be treated as doctor/service query)
  const informationalPatterns = [
    /tell\s+me\s+about/i,
    /what\s+is/i,
    /explain\s+(to\s+me)?/i,
    /how\s+does/i,
    /information\s+(about|on)/i,
    /describe/i,
    /learn\s+about/i
  ];
  
  const isInformational = informationalPatterns.some(pattern => pattern.test(message));
  if (isInformational) {
    console.log('Informational query detected in detectDoctorServiceQuery, skipping doctor/service detection');
    return { isDoctorQuery: false, isServiceQuery: false, serviceName: null };
  }
  
  // Check for doctor/service query patterns - be more aggressive
  // Match ANY question about doctors, even if word order varies
  const hasDoctorWord = /\bdoctors?\b/i.test(message);
  const hasAvailableWord = /\bavailable\b/i.test(message);
  const hasWhichWhat = /^(which|what|who|list|show)/i.test(message.trim());
  
  const doctorPatterns = [
    /which doctors?/i,
    /what doctors?/i,
    /list doctors?/i,
    /show doctors?/i,
    /available doctors?/i,
    /doctors? (available|for|in|who|that|are)/i,
    /who (are|is|can|provides?)/i,
    /doctor.*available/i,
    /available.*doctor/i
  ];
  
  // If message contains "doctor" and "available" or starts with question words, it's likely a doctor query
  const isDoctorQuery = (hasDoctorWord && (hasAvailableWord || hasWhichWhat)) || 
                         doctorPatterns.some(pattern => pattern.test(message));
  
  const servicePatterns = [
    /which service/i,
    /what service/i,
    /services? (available|for|in)/i,
    /available services?/i
  ];
  
  const isServiceQuery = servicePatterns.some(pattern => pattern.test(message));
  
      // Extract service name if mentioned - improved matching
      let serviceName = null;
      const services = getServices();
      
      // Normalize service names for matching
      const normalizeServiceName = (name) => {
        return name.toLowerCase()
          .replace(/physiotherapie/i, 'physiotherapy')
          .replace(/[^a-z0-9]/g, '');
      };
      
      const normalizedMessage = normalizeServiceName(lowerMessage);
      
      // First, try exact match (case-insensitive)
      for (const service of services) {
        if (lowerMessage.includes(service.name.toLowerCase()) || 
            service.name.toLowerCase().includes(normalizedMessage.split(' ').pop())) {
          serviceName = service.name;
          console.log(`Matched "${lowerMessage}" to service: "${serviceName}" (exact match)`);
          break;
        }
      }
      
      // If no exact match, try normalized matching
      if (!serviceName) {
        for (const service of services) {
          const serviceNormalized = normalizeServiceName(service.name);
          
          // Check if service name appears in message
          if (normalizedMessage.includes(serviceNormalized) || 
              serviceNormalized.includes(normalizedMessage.split(' ').pop()) ||
              lowerMessage.includes(service.name.toLowerCase())) {
            serviceName = service.name;
            console.log(`Matched "${lowerMessage}" to service: "${serviceName}" (normalized match)`);
            break;
          }
        }
      }
      
      // Also check for common service variations - prioritize "Physiotherapie"
      if (!serviceName) {
        if (lowerMessage.includes('physiotherapie') || lowerMessage.includes('physiotherapy')) {
          // Find the best matching service - prioritize exact match "Physiotherapie"
          const physioServices = services.filter(s => {
            const normalized = normalizeServiceName(s.name);
            return normalized.includes('physiotherapie') || normalized.includes('physiotherapy');
          });
          
          if (physioServices.length > 0) {
            // Prefer exact match "Physiotherapie" over variations
            const exactMatch = physioServices.find(s => 
              normalizeServiceName(s.name) === 'physiotherapie'
            );
            serviceName = exactMatch ? exactMatch.name : physioServices[0].name;
            console.log(`Matched "${lowerMessage}" to service: "${serviceName}" (physiotherapy match)`);
          }
        }
      }
  
  // Debug logging
  console.log('Doctor query detection:', {
    message,
    hasDoctorWord,
    hasAvailableWord,
    hasWhichWhat,
    isDoctorQuery,
    isServiceQuery,
    serviceName,
    lowerMessage
  });
  
  return { isDoctorQuery, isServiceQuery, serviceName };
}

// Chat endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    const actualSessionId = getOrCreateSession(sessionId);
    
    // Get conversation history for context
    const historyRows = db.prepare(`
      SELECT user_message, bot_response 
      FROM chat_sessions 
      WHERE session_id = ? 
      ORDER BY created_at DESC 
      LIMIT 10
    `).all(actualSessionId);
    
    const conversationHistory = [];
    for (const row of historyRows.reverse()) {
      if (row.user_message) {
        conversationHistory.push({ role: 'user', content: row.user_message });
      }
      if (row.bot_response) {
        conversationHistory.push({ role: 'assistant', content: row.bot_response });
      }
    }
    
    // Classify query intent using OpenAI FIRST - this ensures proper routing
    const queryIntent = await classifyQueryIntent(message, conversationHistory);
    console.log('Query intent classification:', queryIntent);
    
    // If query is informational, skip booking/recommendation checks and go directly to RAG
    if (queryIntent === 'informational') {
      console.log('Informational query detected, using RAG...');
      const result = await generateRAGResponse(message, actualSessionId);
      return res.json({
        response: result.response,
        sources: result.sources,
        sessionId: actualSessionId,
        bookingIntent: false
      });
    }
    
    // Check if user is in booking flow FIRST - before anything else
    // BUT: If the query is informational, answer it regardless of booking state
    const currentBookingState = getBookingState(actualSessionId);
    console.log('Current booking state check:', currentBookingState);
    
    if (currentBookingState && currentBookingState.step && currentBookingState.step !== 'completed' && queryIntent !== 'informational') {
      console.log('User is in booking flow, processing booking message. Step:', currentBookingState.step);
      const bookingResult = await processBookingMessage(message, actualSessionId, conversationHistory);
      
      console.log('Booking result:', {
        step: bookingResult.step,
        continueBooking: bookingResult.continueBooking,
        hasQuickReplies: !!bookingResult.quickReplies
      });
      
      return res.json({
        response: bookingResult.response,
        sources: [],
        sessionId: actualSessionId,
        bookingIntent: true,
        continueBooking: bookingResult.continueBooking || false,
        bookingStep: bookingResult.step,
        quickReplies: bookingResult.quickReplies || [],
        reservationId: bookingResult.reservationId || null,
        availableSlots: bookingResult.availableSlots || null,
        availableDates: bookingResult.availableDates || null
      });
    }
    
    // Check if user wants to start booking - PRIORITY BEFORE RAG
    const wantsToBook = await detectBookingStart(message, conversationHistory);
    if (wantsToBook) {
      console.log('User wants to start booking, initiating booking flow...');
      const bookingResult = await processBookingMessage(message, actualSessionId, conversationHistory);
      
      return res.json({
        response: bookingResult.response,
        sources: [],
        sessionId: actualSessionId,
        bookingIntent: true,
        continueBooking: bookingResult.continueBooking || false,
        bookingStep: bookingResult.step,
        quickReplies: bookingResult.quickReplies || []
      });
    }
    
    // Check if user is describing a medical problem - PRIORITY BEFORE doctor/service queries
    const isProblemDescription = await detectProblemDescription(message, conversationHistory);
    if (isProblemDescription) {
      console.log('Problem description detected, generating recommendations...');
      const recommendationResult = await generateRecommendationResponse(message, actualSessionId, conversationHistory);
      
      if (recommendationResult) {
        console.log('Recommendation generated successfully');
        return res.json({
          response: recommendationResult.response,
          sources: recommendationResult.sources || [],
          sessionId: actualSessionId,
          bookingIntent: false,
          recommendationIntent: true,
          quickReplies: recommendationResult.quickReplies || []
        });
      }
      // If recommendation failed, fall through to doctor/service queries or RAG
    }
    
    // Check for doctor/service queries FIRST (before booking and RAG)
    // BUT: Skip if query is informational or recommendation (already handled)
    if (queryIntent !== 'informational' && queryIntent !== 'recommendation') {
      const queryInfo = await detectDoctorServiceQuery(message);
      
      console.log('Query detection result:', queryInfo);
      
      if (queryInfo.isDoctorQuery) {
        console.log('Doctor query detected, fetching doctors...');
        const doctors = getDoctors();
        let relevantDoctors = doctors;
        
        // If service is mentioned, filter doctors by service (check ALL slots, not just available)
        if (queryInfo.serviceName) {
          console.log(`Filtering doctors for service: "${queryInfo.serviceName}"`);
          
          // Try exact match first
          let allSlots = db.prepare(`
            SELECT provider_name 
            FROM appointment_slots 
            WHERE service_type = ?
          `).all(queryInfo.serviceName);
          
          // Remove duplicates manually since DISTINCT might not work
          const uniqueProviders = new Set(allSlots.map(s => s.provider_name));
          allSlots = Array.from(uniqueProviders).map(p => ({ provider_name: p }));
          
          console.log(`Exact match found ${allSlots.length} doctors for "${queryInfo.serviceName}"`);
          
          // If no exact match, try fuzzy matching - check all slots and filter manually
          if (allSlots.length === 0) {
            console.log(`No exact match for "${queryInfo.serviceName}", trying fuzzy match...`);
            
            // Get all slots and filter manually (since LIKE might not work in database adapter)
            const allSlotsInDb = db.prepare(`
              SELECT provider_name, service_type
              FROM appointment_slots
            `).all();
            
            const normalizedQuery = queryInfo.serviceName.toLowerCase();
            const matchingSlots = allSlotsInDb.filter(slot => {
              const slotService = slot.service_type.toLowerCase();
              return slotService.includes(normalizedQuery) || 
                     normalizedQuery.includes(slotService) ||
                     (normalizedQuery.includes('physiotherapie') && slotService.includes('physiotherapie')) ||
                     (normalizedQuery.includes('physiotherapy') && slotService.includes('physiotherapy'));
            });
            
            if (matchingSlots.length > 0) {
              console.log(`Fuzzy match found ${matchingSlots.length} slots`);
              const uniqueProviders = new Set(matchingSlots.map(s => s.provider_name));
              allSlots = Array.from(uniqueProviders).map(p => ({ provider_name: p }));
              // Update service name to the one found in slots
              queryInfo.serviceName = matchingSlots[0].service_type;
            }
          }
          
          // If still no match, try matching services from database
          if (allSlots.length === 0) {
            console.log(`No slots found, trying to match service names...`);
            const services = getServices();
            const matchingServices = services.filter(s => {
              const serviceLower = s.name.toLowerCase();
              const queryLower = queryInfo.serviceName.toLowerCase();
              return serviceLower.includes(queryLower) || queryLower.includes(serviceLower) ||
                     serviceLower.includes('physiotherapie') || serviceLower.includes('physiotherapy');
            });
            
            if (matchingServices.length > 0) {
              console.log(`Found ${matchingServices.length} matching services:`, matchingServices.map(s => s.name));
              // Try each matching service
              for (const service of matchingServices) {
                const slots = db.prepare(`
                  SELECT provider_name 
                  FROM appointment_slots 
                  WHERE service_type = ?
                `).all(service.name);
                
                // Remove duplicates manually
                const uniqueProviders = new Set(slots.map(s => s.provider_name));
                const uniqueSlots = Array.from(uniqueProviders).map(p => ({ provider_name: p }));
                
                if (uniqueSlots.length > 0) {
                  allSlots = uniqueSlots;
                  queryInfo.serviceName = service.name; // Update to use the actual service name
                  console.log(`Found slots for service: "${service.name}"`);
                  break;
                }
              }
              
              // If still no slots found, create them for the first matching service
              if (allSlots.length === 0 && matchingServices.length > 0) {
                console.log(`No slots exist for "${matchingServices[0].name}", creating them now...`);
                const targetService = matchingServices[0].name;
                const startDate = new Date();
                const endDate = new Date();
                endDate.setDate(endDate.getDate() + 14);
                
                // Create slots for all doctors
                console.log(`Creating slots for ${doctors.length} doctors for service "${targetService}"`);
                let slotsCreated = 0;
                for (const doctor of doctors) {
                  try {
                    const slots = bookingService.createAppointmentSlots(doctor.name, targetService, startDate, endDate);
                    slotsCreated += slots.length;
                    console.log(`Created ${slots.length} slots for ${doctor.name}`);
                  } catch (err) {
                    console.error(`Error creating slots for ${doctor.name}:`, err.message);
                  }
                }
                console.log(`Created ${slotsCreated} total slots for "${targetService}"`);
                
                // Force database reload to ensure writes are visible
                lowDb.read();
                
                // Small delay to ensure database writes are complete
                await new Promise(resolve => setTimeout(resolve, 200));
                
                // Now fetch the slots we just created - try multiple times if needed
                let newSlots = [];
                for (let attempt = 0; attempt < 3; attempt++) {
                  // Force reload before each query
                  lowDb.read();
                  
                  const allSlotsForService = db.prepare(`
                    SELECT provider_name 
                    FROM appointment_slots 
                    WHERE service_type = ?
                  `).all(targetService);
                  
                  // Remove duplicates manually
                  const uniqueProviders = new Set(allSlotsForService.map(s => s.provider_name));
                  newSlots = Array.from(uniqueProviders).map(p => ({ provider_name: p }));
                  
                  if (newSlots.length > 0) {
                    console.log(`Found ${newSlots.length} distinct doctors after creating slots (attempt ${attempt + 1})`);
                    break;
                  } else {
                    console.log(`No slots found yet, waiting... (attempt ${attempt + 1})`);
                    await new Promise(resolve => setTimeout(resolve, 300));
                  }
                }
                
                // If still no slots found, manually extract from all slots
                if (newSlots.length === 0) {
                  console.log('Trying to get all slots and filter manually...');
                  lowDb.read(); // Force reload
                  const allSlotsInDb = db.prepare(`
                    SELECT provider_name, service_type
                    FROM appointment_slots
                  `).all();
                  const matching = allSlotsInDb.filter(s => s.service_type === targetService);
                  const uniqueProviders = new Set(matching.map(s => s.provider_name));
                  newSlots = Array.from(uniqueProviders).map(p => ({ provider_name: p }));
                  console.log(`Manually found ${newSlots.length} doctors for "${targetService}"`);
                }
                
                allSlots = newSlots;
                queryInfo.serviceName = targetService;
                console.log(`Final result: ${allSlots.length} doctors with slots for "${targetService}"`);
              }
            }
          }
          
          const doctorsWithService = new Set(allSlots.map(s => s.provider_name));
          relevantDoctors = doctors.filter(d => doctorsWithService.has(d.name));
          
          console.log(`Found ${relevantDoctors.length} doctors who provide ${queryInfo.serviceName}`);
          console.log(`Doctors with service:`, Array.from(doctorsWithService));
          
          // If no slots found for this service, indicate that
          if (relevantDoctors.length === 0) {
            console.log(`No doctors found for service "${queryInfo.serviceName}"`);
            return res.json({
              response: `I don't have appointment slots configured for ${queryInfo.serviceName} yet. However, here are all our doctors:\n\n${doctors.map((d, idx) => `${idx + 1}. ${d.name}`).join('\n')}\n\nWould you like to book an appointment? Our team can help you find the right doctor for ${queryInfo.serviceName}.`,
              sources: [],
              sessionId: actualSessionId,
              bookingIntent: false,
              quickReplies: ['Book Appointment']
            });
          }
        }
        
        if (relevantDoctors.length > 0) {
          // Format doctor list nicely
          const doctorList = relevantDoctors
            .map((d, idx) => `${idx + 1}. ${d.name}`)
            .join('\n');
          
          const response = queryInfo.serviceName 
            ? `Here are the doctors available for ${queryInfo.serviceName}:\n\n${doctorList}\n\nWould you like to book an appointment with any of these doctors?`
            : `Here are our doctors:\n\n${doctorList}\n\nWould you like to book an appointment with any of them?`;
          
          console.log('Returning doctor list response');
          return res.json({
            response: response,
            sources: [],
            sessionId: actualSessionId,
            bookingIntent: false,
            quickReplies: relevantDoctors.slice(0, 5).map(d => `Book with ${d.name}`)
          });
        }
      }
      
      // Handle service queries
      if (queryInfo.isServiceQuery) {
          const services = getServices();
          const serviceList = services.slice(0, 10).map((s, idx) => `${idx + 1}. ${s.name}`).join('\n');
          return res.json({
            response: `Here are our services:\n\n${serviceList}\n\nWould you like to book an appointment for any of these services?`,
            sources: [],
            sessionId: actualSessionId,
            bookingIntent: false,
            quickReplies: ['Book Appointment']
          });
        }
    }
    
    // Check if this is a booking-related conversation
    const bookingResponse = await generateBookingResponse(message, conversationHistory);
    
    if (bookingResponse) {
      // Check if user wants to proceed with booking
      const confirmation = await checkBookingConfirmation(message, [
        ...conversationHistory,
        { role: 'user', content: message }
      ]);
      
      return res.json({
        response: bookingResponse.response,
        sources: [],
        sessionId: actualSessionId,
        bookingIntent: true,
        initiateBooking: confirmation.wantsToBook || false,
        selectedDoctor: confirmation.selectedDoctor || bookingResponse.intent?.doctor_name || null,
        selectedDate: confirmation.selectedDate || bookingResponse.intent?.preferred_date || null,
        quickReplies: bookingResponse.quickReplies || []
      });
    }
    
    // Regular RAG response
    const result = await generateRAGResponse(message, actualSessionId);
    
    res.json({
      response: result.response,
      sources: result.sources,
      sessionId: actualSessionId,
      bookingIntent: false
    });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Failed to process chat message' });
  }
});

// Text-to-Speech endpoint - STREAMING for faster response
app.post('/api/text-to-speech', async (req, res) => {
  try {
    const { text, voiceId } = req.body;
    
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text is required' });
    }

    if (!process.env.ELEVENLABS_API_KEY) {
      return res.status(500).json({ 
        error: 'ElevenLabs API key not configured', 
        details: 'Please add ELEVENLABS_API_KEY to your .env file' 
      });
    }

    // Stream audio chunks as they arrive from ElevenLabs
    // Send headers immediately to start streaming faster
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.writeHead(200); // Send headers immediately
    
    try {
      const { ElevenLabsClient } = await import('@elevenlabs/elevenlabs-js');
      const elevenlabs = new ElevenLabsClient({
        apiKey: process.env.ELEVENLABS_API_KEY
      });

      const DEFAULT_VOICE_ID = '21m00Tcm4TlvDq8ikWAM';
      
      // Clean up text
      const cleanText = text
        .replace(/#{1,6}\s*/g, '')
        .replace(/\*\*/g, '')
        .replace(/\*/g, '')
        .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')
        .replace(/\n{3,}/g, '\n\n')
        .trim();

      // Stream audio directly to response - flush immediately for faster response
      const audioStream = await elevenlabs.textToSpeech.convert(voiceId || DEFAULT_VOICE_ID, {
        text: cleanText,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
          style: 0.0,
          use_speaker_boost: false
        }
      });

      // Pipe chunks directly to response (streaming) - flush each chunk immediately
      for await (const chunk of audioStream) {
        res.write(chunk);
        // Force flush to send chunk immediately (Node.js buffers by default)
        if (typeof res.flush === 'function') {
          res.flush();
        }
      }
      
      res.end();
    } catch (error) {
      console.error('ElevenLabs streaming error:', error);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Failed to generate speech', details: error.message });
      } else {
        res.end();
      }
    }
  } catch (error) {
    console.error('TTS error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Failed to process TTS request', details: error.message });
    }
  }
});

// Get available doctors
app.get('/api/doctors', (req, res) => {
  try {
    const doctors = getDoctors();
    console.log(`Returning ${doctors.length} doctors`);
    res.json(doctors);
  } catch (error) {
    console.error('Error fetching doctors:', error);
    res.json([]);
  }
});

// Get available services
app.get('/api/services', (req, res) => {
  try {
    const services = getServices();
    console.log(`Returning ${services.length} services`);
    res.json(services);
  } catch (error) {
    console.error('Error fetching services:', error);
    // Return default services on error
    const defaultServices = [
      { id: 'default_1', name: 'General Consultation', created_at: new Date().toISOString() },
      { id: 'default_2', name: 'Physical Therapy', created_at: new Date().toISOString() },
      { id: 'default_3', name: 'Physiotherapy', created_at: new Date().toISOString() },
      { id: 'default_4', name: 'Infusion Therapy', created_at: new Date().toISOString() },
      { id: 'default_5', name: 'Consultation', created_at: new Date().toISOString() }
    ];
    res.json(defaultServices);
  }
});
app.get('/api/slots/appointments', (req, res) => {
  try {
    let slots = bookingService.getAvailableSlots(req.query);
    
    // If no slots found, automatically create some for the next 2 weeks
    if (!slots || slots.length === 0) {
      console.log('No slots found, creating sample slots...');
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 14);
      
      bookingService.createAppointmentSlots('Dr. Smith', 'General Consultation', startDate, endDate);
      bookingService.createAppointmentSlots('Dr. Jones', 'Physical Therapy', startDate, endDate);
      
      // Fetch again after creating
      slots = bookingService.getAvailableSlots(req.query);
    }
    
    res.json(slots || []);
  } catch (error) {
    console.error('Error fetching slots:', error);
    res.status(500).json({ error: 'Failed to fetch appointment slots' });
  }
});

// Hold appointment slot
app.post('/api/slots/appointments/:slotId/hold', (req, res) => {
  try {
    const { slotId } = req.params;
    const { sessionId: providedSessionId } = req.body;
    
    // Use the provided sessionId directly - don't create a new one
    // This ensures the sessionId matches when confirming
    if (!providedSessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    
    const sessionId = providedSessionId;
    
    console.log('Holding appointment slot:', {
      slotId,
      sessionId
    });
    
    const result = bookingService.holdSlot(slotId, sessionId);
    res.json({ ...result, sessionId });
  } catch (error) {
    console.error('Hold error:', error);
    res.status(400).json({ error: error.message });
  }
});

// Confirm appointment reservation
app.post('/api/reservations/appointments', (req, res) => {
  try {
    const { slotId, patientData, sessionId: providedSessionId } = req.body;
    
    // Use the provided sessionId directly - don't create a new one
    // The slot must be held by this exact sessionId
    if (!providedSessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    
    const sessionId = providedSessionId;
    
    console.log('Confirm reservation request:', {
      slotId,
      providedSessionId,
      sessionId
    });
    
    const result = bookingService.confirmReservation(slotId, sessionId, patientData);
    res.json(result);
  } catch (error) {
    console.error('Reservation error:', error);
    res.status(400).json({ error: error.message });
  }
});

// Cancel reservation
app.post('/api/reservations/:reservationId/cancel', (req, res) => {
  try {
    const { reservationId } = req.params;
    const sessionId = getOrCreateSession(req.body.sessionId);
    
    const result = bookingService.cancelReservation(reservationId, sessionId);
    res.json(result);
  } catch (error) {
    console.error('Cancel error:', error);
    res.status(400).json({ error: error.message });
  }
});

// Get available parking slots
app.get('/api/slots/parking', (req, res) => {
  try {
    const slots = parkingService.getAvailableParkingSlots(req.query);
    res.json(slots);
  } catch (error) {
    console.error('Error fetching parking slots:', error);
    res.status(500).json({ error: 'Failed to fetch parking slots' });
  }
});

// Hold parking slot
app.post('/api/slots/parking/:slotId/hold', (req, res) => {
  try {
    const { slotId } = req.params;
    const { sessionId: providedSessionId } = req.body;
    
    // Use the provided sessionId directly - don't create a new one
    // This ensures the sessionId matches when confirming
    if (!providedSessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    
    const sessionId = providedSessionId;
    
    console.log('Holding parking slot:', {
      slotId,
      sessionId
    });
    
    const result = parkingService.holdParkingSlot(slotId, sessionId);
    res.json({ ...result, sessionId });
  } catch (error) {
    console.error('Parking hold error:', error);
    res.status(400).json({ error: error.message });
  }
});

// Confirm parking reservation
app.post('/api/reservations/parking', (req, res) => {
  try {
    const { slotId, patientData, sessionId: providedSessionId } = req.body;
    
    // Use the provided sessionId directly - don't create a new one
    // The slot must be held by this exact sessionId
    if (!providedSessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    
    const sessionId = providedSessionId;
    
    console.log('Confirm parking reservation request:', {
      slotId,
      providedSessionId,
      sessionId
    });
    
    const result = parkingService.confirmParkingReservation(slotId, sessionId, patientData);
    res.json(result);
  } catch (error) {
    console.error('Parking reservation error:', error);
    res.status(400).json({ error: error.message });
  }
});

// Upload and process audio
app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const { createReadStream } = await import('fs');
    const fileStream = createReadStream(req.file.path);
    
    const result = await processAudioFile(
      fileStream,
      req.file.originalname,
      req.file.size
    );
    
    res.json(result);
  } catch (error) {
    console.error('Transcription error:', error);
    res.status(500).json({ error: 'Failed to process audio file' });
  }
});

// Get transcript
app.get('/api/transcripts/:transcriptId', (req, res) => {
  try {
    const { transcriptId } = req.params;
    const transcript = db.prepare('SELECT * FROM transcripts WHERE id = ?').get(transcriptId);
    
    if (!transcript) {
      return res.status(404).json({ error: 'Transcript not found' });
    }
    
    res.json({
      ...transcript,
      attendees: JSON.parse(transcript.attendees || '[]'),
      action_items: JSON.parse(transcript.action_items || '[]'),
      extracted_info: JSON.parse(transcript.extracted_info || '{}')
    });
  } catch (error) {
    console.error('Error fetching transcript:', error);
    res.status(500).json({ error: 'Failed to fetch transcript' });
  }
});

// Crawl site endpoint (admin)
// Admin endpoint to create slots for a specific service
app.post('/api/admin/create-slots-for-service', async (req, res) => {
  try {
    const { serviceName, days = 14 } = req.body;
    
    if (!serviceName) {
      return res.status(400).json({ error: 'serviceName is required' });
    }
    
    const doctors = getDoctors();
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + parseInt(days));
    
    let slotsCreated = 0;
    for (const doctor of doctors) {
      const slots = bookingService.createAppointmentSlots(doctor.name, serviceName, startDate, endDate);
      slotsCreated += slots.length;
    }
    
    res.json({ 
      success: true, 
      message: `Created ${slotsCreated} slots for ${serviceName} across ${doctors.length} doctors`,
      doctors: doctors.length,
      slotsCreated
    });
  } catch (error) {
    console.error('Error creating slots:', error);
    res.status(500).json({ error: 'Failed to create slots', details: error.message });
  }
});

// Admin endpoint to trigger doctor/service extraction
app.post('/api/admin/extract-doctors-services', async (req, res) => {
  try {
    console.log('Manual extraction triggered...');
    const { doctors, services } = await extractDoctorsAndServices();
    res.json({ 
      success: true, 
      doctors: doctors.length, 
      services: services.length,
      doctorList: doctors,
      serviceList: services
    });
  } catch (error) {
    console.error('Extraction error:', error);
    res.status(500).json({ error: 'Failed to extract doctors and services', details: error.message });
  }
});

app.post('/api/admin/crawl', async (req, res) => {
  try {
    const { siteUrl } = req.body;
    const targetUrl = siteUrl || process.env.TARGET_SITE || 'https://functiomed.ch';
    console.log(`Starting crawl of ${targetUrl}...`);
    const result = await crawlSite(targetUrl);
    res.json({ 
      success: true,
      message: `Crawled ${result.pages} pages and stored ${result.chunks} chunks`,
      ...result 
    });
  } catch (error) {
    console.error('Crawl error:', error);
    res.status(500).json({ error: 'Failed to crawl site', details: error.message });
  }
});

// Check knowledge base status
app.get('/api/admin/knowledge-status', async (req, res) => {
  try {
    const chunks = db.prepare('SELECT COUNT(*) as count FROM knowledge_chunks').get();
    const pages = db.prepare('SELECT COUNT(DISTINCT url) as count FROM knowledge_chunks').get();
    res.json({
      totalChunks: chunks?.count || 0,
      totalPages: pages?.count || 0,
      hasContent: (chunks?.count || 0) > 0
    });
  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({ error: 'Failed to check status' });
  }
});

// Background job: cleanup expired holds
setInterval(() => {
  try {
    const expired = bookingService.cleanupExpiredHolds();
    const expiredParking = parkingService.cleanupExpiredParkingHolds();
    if (expired > 0 || expiredParking > 0) {
      console.log(`Cleaned up ${expired} expired appointment holds and ${expiredParking} parking holds`);
    }
  } catch (error) {
    console.error('Cleanup error:', error);
  }
}, 60000); // Every minute

// Initialize with sample data on startup
(async () => {
  try {
    // Check if we have any appointment slots
    const slots = bookingService.getAvailableSlots();
    const slotCount = slots?.length || 0;
    
    if (slotCount === 0 || process.env.INIT_SAMPLE_DATA === 'true') {
      console.log('Initializing appointment slots...');
      
      // Create some sample appointment slots for the next 2 weeks
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 14);
      
      const slots1 = bookingService.createAppointmentSlots('Dr. Smith', 'General Consultation', startDate, endDate);
      const slots2 = bookingService.createAppointmentSlots('Dr. Jones', 'Physical Therapy', startDate, endDate);
      
      console.log(`Created ${slots1.length + slots2.length} appointment slots`);
    } else {
      console.log(`✅ Found ${slotCount} available appointment slots`);
    }
    
    // Check parking slots
    const allParkingSlots = db.prepare('SELECT * FROM parking_slots').all();
    const parkingCount = allParkingSlots?.length || 0;
    
    // Check unique spots
    const uniqueSpots = new Set(allParkingSlots.map(s => s.spot_identifier));
    const expectedSpots = ['P1', 'P2', 'P3', 'P4', 'P5'];
    const missingSpots = expectedSpots.filter(s => !uniqueSpots.has(s));
    
    if (parkingCount === 0 || process.env.INIT_SAMPLE_DATA === 'true' || missingSpots.length > 0) {
      console.log('Initializing parking slots...');
      if (missingSpots.length > 0) {
        console.log(`Missing spots: ${missingSpots.join(', ')}, creating them...`);
      }
      parkingService.initializeParkingSlots(['P1', 'P2', 'P3', 'P4', 'P5'], 'Main');
      console.log('Parking slots initialized');
    } else {
      console.log(`✅ Found ${parkingCount} parking slots with ${uniqueSpots.size} unique spots`);
      
      // Cleanup duplicates if any exist
      const spotMap = new Map();
      let duplicatesFound = 0;
      
      for (const slot of allParkingSlots) {
        const dateStr = slot.start_time?.split('T')[0] || new Date(slot.start_time).toISOString().split('T')[0];
        const key = `${slot.spot_identifier}_${slot.zone}_${dateStr}`;
        
        if (spotMap.has(key)) {
          // Duplicate found - remove it
          db.prepare('DELETE FROM parking_slots WHERE id = ?').run(slot.id);
          duplicatesFound++;
        } else {
          spotMap.set(key, slot);
        }
      }
      
      if (duplicatesFound > 0) {
        console.log(`🧹 Cleaned up ${duplicatesFound} duplicate parking slots`);
      }
    }
  } catch (error) {
    console.error('Error initializing sample data:', error);
  }
})();

// Check knowledge base on startup
(async () => {
  try {
    const chunks = db.prepare('SELECT COUNT(*) as count FROM knowledge_chunks').get();
    const chunkCount = chunks?.count || 0;
    
    if (chunkCount === 0) {
      const pages = db.prepare('SELECT COUNT(DISTINCT url) as count FROM knowledge_chunks').get();
      console.log(`\n⚠️  Knowledge base is empty!`);
    } else {
      const pages = db.prepare('SELECT COUNT(DISTINCT url) as count FROM knowledge_chunks').get();
      console.log(`\n✅ Knowledge base loaded: ${pages?.count || 0} pages, ${chunkCount} chunks\n`);
    }
  } catch (error) {
    console.error('Error checking knowledge base:', error);
  }
})();

app.listen(PORT, async () => {
  console.log(`Server running on http://localhost:${PORT}`);
  
  // Auto-crawl if knowledge base is empty (run in background after server starts)
  setTimeout(async () => {
    try {
      const chunks = db.prepare('SELECT COUNT(*) as count FROM knowledge_chunks').get();
      const chunkCount = chunks?.count || 0;
      
      if (chunkCount === 0) {
        console.log('\n⚠️  Knowledge base is empty!');
        console.log('   Starting automatic crawl of Functiomed.ch website...');
        console.log('   This may take a few minutes. The server will continue running.\n');
        
        try {
          const targetUrl = process.env.TARGET_SITE || 'https://functiomed.ch';
          const result = await crawlSite(targetUrl);
          console.log(`\n✅ Crawl completed successfully!`);
          console.log(`   Crawled ${result.pages} pages and stored ${result.chunks} chunks`);
          console.log(`   Knowledge base is now ready to use.\n`);
        } catch (error) {
          console.error('\n❌ Error during automatic crawl:', error.message);
          console.log('   You can manually trigger a crawl by:');
          console.log('   - Running: npm run crawl');
          console.log('   - Or POST to /api/admin/crawl endpoint\n');
        }
      }
    } catch (error) {
      console.error('Error during auto-crawl:', error);
    }
  }, 2000); // Wait 2 seconds after server starts
  
  // Ensure slots are initialized after server starts
  setTimeout(async () => {
    try {
      const slots = bookingService.getAvailableSlots();
      if (!slots || slots.length === 0) {
        console.log('No slots found on startup, initializing...');
        const startDate = new Date();
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + 14);
        
        // Get doctors and services from website
        const doctors = getDoctors();
        const services = getServices();
        
        console.log(`Found ${doctors.length} doctors and ${services.length} services`);
        
        if (doctors.length > 0 && services.length > 0) {
          // Create slots for each doctor-service combination
          for (const doctor of doctors) {
            for (const service of services) {
              bookingService.createAppointmentSlots(doctor.name, service.name, startDate, endDate);
            }
          }
          console.log(`✅ Initialized slots for ${doctors.length} doctors and ${services.length} services`);
        } else {
          // Fallback to sample data if no website data
          console.log('⚠️  No doctors/services found in database, using sample data...');
          bookingService.createAppointmentSlots('Dr. Smith', 'General Consultation', startDate, endDate);
          bookingService.createAppointmentSlots('Dr. Jones', 'Physical Therapy', startDate, endDate);
        }
        console.log('✅ Appointment slots initialized');
      } else {
        console.log(`Initialized ${slots.length} appointment slots`);
      }
    } catch (error) {
      console.error('Error checking/initializing slots:', error);
    }
  }, 1000);
});

